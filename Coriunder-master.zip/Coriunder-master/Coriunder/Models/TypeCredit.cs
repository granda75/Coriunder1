﻿

namespace Coriunder.Models
{
    public enum TypeCredit
    {
        Debit = 1,
        Installments = 8,
        Refund = 0
       
    }
}