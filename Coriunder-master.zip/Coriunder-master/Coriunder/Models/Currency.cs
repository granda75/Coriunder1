﻿

namespace Coriunder.Models
{
    public enum Currency
    {
        ILS = 0,
        USD = 1,
        EUR = 2, 
        GBP = 3
    }
}